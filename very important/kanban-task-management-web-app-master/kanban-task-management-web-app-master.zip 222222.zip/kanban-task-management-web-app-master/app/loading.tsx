import Spinner from "@/app/_components/Spinner";

function loading() {
  return <Spinner />;
}

export default loading;
